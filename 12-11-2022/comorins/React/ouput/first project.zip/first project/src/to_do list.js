import { useState } from 'react';
import Todo from './todo';
import Displayitem from './displayitem'

const  Todo_list=()=>{

    const[todo,setTodo]=useState([]);
    // const[edit,setEdit]=useState(" ")

    const getitem=(get)=>{
        setTodo((arr)=>{
            return[...arr,{name:get,status:false}]
        })
    }

    const deleteitem=(id)=>{
        setTodo((arr)=>{
            return arr.filter((items,index)=>{
                return index !==id;
            })
        })
    }
    const Completedfn=(completename)=>{
        let completeitem=todo.map((value)=>{
            if(value.name===completename.name){
                return {...value,status:!value.status}
            }
        })
        setTodo(completeitem)
    }

    // const update=(getitem)=>{
    //     let updateitem=todo.find((value)=> value.name===getitem.name)
    //     setEdit(updateitem.name)
    // }
    return(<>
       <div className='container'>
            <h1 className="text-center">To-Do List</h1>
            <Todo setTodo={getitem}/>
            <div className='container'>
                <table className="table mt-5">
                    <thead>
                        <tr>
                            <th scope="col" className="text-center heading">ID</th>
                            <th scope="col" className="text-center heading">To Do</th>
                            <th scope="col" className="text-center heading">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    {
                        todo.map((items,index)=>{
                            return(<Displayitem  key={index} obj={items}  todoname={items.name} delete={deleteitem} Completedfn={Completedfn} id={index} />)
                        })
                    }
                    </tbody>
                </table>
            </div>
        </div>
    </>)
}

export default Todo_list