import { useState } from "react"

function Todo(props){
    const [value,setValue]=useState("");

    const listsave=(val)=>{
        setValue(val.target.value)
    }
    const add=()=>{
        if(value!==" "){
            props.setTodo(value);
            setValue(" ");
        }else{
            alert("Please add anything")
        }
    }

    return(<>
        <div className="text-center">
        <input onChange={listsave} className="inputfield" type="text" placeholder="Add Todo" value={value}/>
        <button className="m-2 button" onClick={add} >Add</button>
        </div>
        
    </>)
}
export default Todo