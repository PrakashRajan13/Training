const Displayitem=(props)=>{

    return(
            <tr>
                <td className="text-center">{props.id+1}</td>
                <td className= {props.obj.status?"done text-center":"text-center"}>{props.todoname}</td>
                <td className="text-center">
                    <button className="m-2 button bg-danger btn" value="" onClick={()=>props.delete(props.id)}>Delete</button>
                    <button className="button bg-success btn"  value="" onClick={()=>props.Completedfn(props.obj)}>{props.obj.status?"InComplete":"Complete"}</button>
                    {/* <button className="m-2 button bg-primary btn" value="" onClick={()=>props.update(props.obj)}>Edit</button> */}
                </td>
            </tr>

    )
}
export default Displayitem