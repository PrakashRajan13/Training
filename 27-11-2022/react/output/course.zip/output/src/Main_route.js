import React, { useState } from "react";
import {
    BrowserRouter as Router,
    Routes,
    Route,

  } from "react-router-dom";
import Login from "./pages/Login";
import Home from "./pages/Home";
import Register from "./pages/Register";
import Course from "./pages/Course";
import CourseDetail from "./pages/CourseDetail";
import Createcourse from "./pages/Create_course";
import Usercontext from "./UserContext";

  export default function Main_route(){
    const[islog,setIsLog]=useState(false)
    const[userdata,setUserData]=useState({})
    return(
      <Usercontext.Provider value={{islog,setIsLog,userdata,setUserData}}>
        <Router>
            <Routes>
                <Route path="/" exact element={<Login/>}/>
                <Route path="/home" element={<Home/>}/>
                <Route path="/Register" element={<Register/>}/>
                <Route path="/Course" element={<Course/>}/>
                <Route path="/Createcourse" element={<Createcourse/>}/>
                <Route path="/CourseDetail/:id" element={<CourseDetail/>}/>
            </Routes>
        </Router>
      </Usercontext.Provider>
    )
  }