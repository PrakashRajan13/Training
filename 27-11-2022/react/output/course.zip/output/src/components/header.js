export default function Header(){
    return(<>
        <div className="bg-dark">
            <h1 className="p-3 text-center text-white">Course Application</h1>
        </div>
    </>)
}