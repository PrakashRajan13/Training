import React,{useState,useEffect} from "react";
import { Link } from "react-router-dom";
import axios from 'axios'
import '../App.css';

export default function Getcourse(){


        const [courseList,setCourseList] = useState([]);
    
        useEffect(()=>{
                getCourseList();
        },
        []
        )
    
        const getCourseList = async() => {
            const {data} = await axios.get('http://karka.academy/api/action.php?request=getCourses')
            setCourseList(data.data)
            
        }
    
    
        return (<>
    
                <ul className="mt-3">
                    {courseList.map((item,index)=><li key={index}><Link className="course" to={`/CourseDetail/${item.id}`}>{item.name}</Link></li>)}
                </ul>
            </>
    
        )
    }
