import Nav from 'react-bootstrap/Nav';
import { Link } from 'react-router-dom';
import '../App.css';
import Usercontext from "../UserContext";
import { useContext } from "react"


export default function Navigation({setIsLog}){
    const value=useContext(Usercontext)
    const {userdata}=value
    console.log(userdata)
    return(<>
            <Nav className='mt-3'>
                <Nav.Item>
                <Link to="/Home" className='nav-items'>Home</Link>
                </Nav.Item>
                <Nav.Item>
                    <Link to='/Course' className='nav-items'>Course</Link>
                </Nav.Item>
                <Nav.Item>
                    <Link to='/Createcourse' className='nav-items'>Create Course</Link>
                </Nav.Item>
                <Nav.Item>
                    <Link to='/' className='nav-items' onClick={()=>{setIsLog(false);localStorage.setItem("key",false);localStorage.setItem("name","")}}>Logout</Link>
                </Nav.Item>

            </Nav>
    </>
    )
}