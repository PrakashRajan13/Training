import axios from 'axios';
import { useState,useEffect,useContext } from 'react'
import FloatingLabel from 'react-bootstrap/FloatingLabel';
import Form from 'react-bootstrap/Form';
import Navigation from "../components/navigation";
import Header from '../components/header';
import { useNavigate} from "react-router-dom";
import Usercontext from '../UserContext';

export default function Createcourse(){
    const[newcourse,setNewCourse]=useState({
        request: "create_course",name:"",video_id:"",description:"",price:""
    })
    const value=useContext(Usercontext)
    const {islog,setIsLog,userdata}=value
    let navigate = useNavigate();

    useEffect(()=>{
        if(islog || localStorage.getItem("key")) navigate('/Createcourse')
    
},
[islog]
)

    const create_course=async()=>{
        const data=await axios.post('http://karka.academy/api/action.php',JSON.stringify(newcourse))
        setNewCourse({...newcourse,name:"",video_id:"",description:"",price:""})
        // if(data.status==="success"){
          

        // }
    }
    return(<>
        <Header/>
    <div className='container'>
     <Navigation />
        <div className='container register_form mt-5'>

            <FloatingLabel
            controlId="floatingInput"
            label="Name"
            className="mb-3"
        >
            <Form.Control value={newcourse.name} onChange={(e)=>setNewCourse({...newcourse,name:e.target.value})} type="text" placeholder="Name"/>
        </FloatingLabel>
        <FloatingLabel className="mb-3" controlId="floatingInput" label="video_id">
            <Form.Control  value={newcourse.video_id} type="text" onChange={(e)=>setNewCourse({...newcourse,video_id:e.target.value})} placeholder="Email ID"/>
        </FloatingLabel>
        <FloatingLabel className="mb-3" controlId="floatingPassword" label="description">
            <Form.Control  value={newcourse.description} type="text" onChange={(e)=>setNewCourse({...newcourse,description:e.target.value})} placeholder="Password"/>
        </FloatingLabel>
        <FloatingLabel className="mb-3" controlId="floatingInput" label="Price">
            <Form.Control  value={newcourse.price} type="number" onChange={(e)=>setNewCourse({...newcourse,price:e.target.value})} placeholder="Adhaar Number"/>
        </FloatingLabel>
        <div className='submit'>
                <button className='btn bg-primary text-light m-3' onClick={create_course}>Create</button>
            </div>
        </div>
        </div>
    </>)
}