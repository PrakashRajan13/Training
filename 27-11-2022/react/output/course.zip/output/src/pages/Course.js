import Navigation from "../components/navigation";
import {useEffect,useContext } from "react"
import { useNavigate } from "react-router-dom";
import Getcourse from "../components/getcourse";
import Header from "../components/header";
import Usercontext from "../UserContext";
import '../App.css';

export default function Course(){
    const navigate=useNavigate()
    const value=useContext(Usercontext)
    const {islog,setIsLog,userdata}=value
    
//     useEffect(()=>{
//         if(!islog) navigate('/')
// },[]
// )
    return(<>
        <Header/>
        <div className="container">
            <Navigation/>
            <div className="container mt-4">
                <h1 className="mt-3">Course List</h1>
                <Getcourse/>
            </div>
        </div>
    </>)
}