import React,{useState,useEffect,useContext} from "react";
import { useNavigate,useParams } from "react-router-dom";
import axios from 'axios'
import Getcourse from "../components/getcourse";
import Navigation from "../components/navigation";
import Card from 'react-bootstrap/Card';
import Header from "../components/header";
import Usercontext from "../UserContext";


export default function CourseDetail(){
    const params = useParams();
    const [courseDetails,setCourseDetails] = useState({});
    const value=useContext(Usercontext)
    const {islog,setIsLog}=value
    let navigate = useNavigate();


    useEffect(()=>{
            if(!islog) navigate('/')
            getCourseDetails(params.id);
            window.scrollTo(0,0)
    },
    [islog,params.id]
    )

    const getCourseDetails = async() => {
        const {data} = await axios.get(`http://karka.academy/api/action.php?request=getCourseDetails&id=${params.id}`)
        setCourseDetails(data.data)  
    }



    return (<>
            <Header/>
            <div className="container">
                <Navigation/>
                <Card className="mt-5">
                    <Card.Header  as="h5">{courseDetails.name}</Card.Header>
                    <Card.Body>
                        <Card.Title>Video_id - {courseDetails.video_id}</Card.Title>
                        <Card.Text>Description - {courseDetails.description}</Card.Text>
                        <Card.Text>Price - {courseDetails.price}</Card.Text>
                        <Card.Text>Time - {courseDetails.time}</Card.Text>
                    </Card.Body>
                </Card>
                <Getcourse />
            </div>
           
            
        </>

    )
}