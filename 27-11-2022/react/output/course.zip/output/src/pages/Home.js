import Navigation from "../components/navigation"
import {useContext, useEffect } from "react"
import { useNavigate } from "react-router-dom";
import Header from "../components/header";
import Usercontext from "../UserContext";

export default function Home(){
    const navigate=useNavigate()
    const value=useContext(Usercontext)
    const {islog,setIsLog}=value
    useEffect(()=>{
        if(!islog || localStorage.getItem("key")) {navigate('/Home')}
},
[islog, navigate]
)

    return(
        <>
        <Header/>
        <div className="container">
            <Navigation islog={islog} setIsLog={setIsLog}/>
            <div className="container mt-4">
                <b>Welcome {localStorage.getItem("name")}</b>
                <h1 className="mt-3">This is Home Page</h1>
            </div>
        </div>
        </>
    )
}