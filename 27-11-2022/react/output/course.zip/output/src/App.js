import Main_route from './Main_route';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
   <>
    <Main_route/>
   </>
  );
}

export default App;
