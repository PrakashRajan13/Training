const Header =()=>{
    return(<>
        <div className="bg-dark">
        <h1 className="text-center text-light p-3">Course Application</h1>
        </div>
       
    </>)
}

export default Header