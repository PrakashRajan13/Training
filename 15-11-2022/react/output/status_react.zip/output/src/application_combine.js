import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import Loginform from './pages/loginform';
import Registerform from './pages/registerform';
import Home from './pages/home';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";


function Combine() {
  
  return (
   <>
   <Router>
      <div>
        <nav>
          <ul>
            <li>
              <Link to="/registerform">register</Link>
            </li>
            <li>
              <Link to="/loginform">Login</Link>
            </li>
            <li>
              <Link to="/Home">Home</Link>
            </li>
          </ul>
        </nav>
        <Switch>
          <Route path="/registerform">
            <Registerform />
          </Route>
          <Route path="/loginform">
            <Loginform />
          </Route>
          <Route path="/Home">
            <Home />
          </Route>
        </Switch>
      </div>
    </Router>
   </>
  );
}

export default Combine;
