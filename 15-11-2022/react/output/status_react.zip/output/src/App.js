import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import Combine from "./application_combine";
// import Statusindex from "./status";


function App() {
  
  return (
   <>
    <Combine/>
    {/* <Statusindex/> */}
    
   </>
  );
}

export default App;
