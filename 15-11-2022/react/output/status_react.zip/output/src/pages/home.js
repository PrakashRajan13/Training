import { useLocation } from "react-router-dom";
const Home =()=>{
    
    const location=useLocation();


    return(<>
    <div className="text-center">
        <h1>This is Home Page</h1>
        <h1>Welcome, {location.state.name}</h1>
        <h1>{location.state.password}</h1>
    </div>
    </>)
}

export default Home;