import { useState } from 'react';
import FloatingLabel from 'react-bootstrap/FloatingLabel';
import Form from 'react-bootstrap/Form';
import Header from '../components/header'
import { useHistory } from 'react-router-dom';
import '../App.css';

const Loginform =()=>{
    const[name,setName]=useState("");
    const[password,setPassword]=useState("");

    const history=useHistory()

    
    const check =()=>{
      if(name==="prakash" && password==="123" ){
        history.push({
          pathname: '/Home',
          search: '?page=Home',
          state: { name:name,password:password }
        })
        setName("")
        setPassword("")
      }else{
        alert("Invalid")
        setName("")
        setPassword("")
      }
    }
    window.history.forward();
    // const data={
    //     "request" : "create_candidate",
    //     "email" : "jegan",
    //     "password" : 1234567890
    // }
    // const url="http://karka.academy/api/action.php"
    // const check =()=>{
    //   fetch(url,{method:"post",body:JSON.stringify(data)}).then(response=>response.json()).then(data=>console.log(data)).catch(err=>console.log(err))
    // }
    return(
    <>
    <Header/>
    <div className="container login">
      <FloatingLabel
        controlId="floatingInput"
        label="User name"
        className="mb-3"
      >
        <Form.Control type="text" placeholder="name@example.com" value={name} onChange={(e)=>{setName(e.target.value)}} />
      </FloatingLabel>
      <FloatingLabel controlId="floatingPassword" label="Password">
        <Form.Control type="password" placeholder="Password" value={password} onChange={(e)=>{setPassword(e.target.value)}} />
      </FloatingLabel>
      <div className='submit'>
        <button className='btn bg-primary text-light m-3' onClick={()=>check()}>Login</button>
      </div>
    </div>
    </>
)
}
export default Loginform