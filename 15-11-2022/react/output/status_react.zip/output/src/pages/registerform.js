import Header from '../components/header'
import FloatingLabel from 'react-bootstrap/FloatingLabel';
import Form from 'react-bootstrap/Form';

const Registerform =()=>{
    return(
        <>
        <Header/>
        <div className="container login">
            <FloatingLabel
            controlId="floatingInput"
            label="Name"
            className="mb-3 mt-5">
            <Form.Control type="text" placeholder="name@example.com" />
            </FloatingLabel>
            <FloatingLabel className="mb-3" controlId="floatingInput" label="Username">
                <Form.Control type="text" placeholder="Username" />
            </FloatingLabel>
            <FloatingLabel className="mb-3" controlId="floatingPassword" label="Password">
                <Form.Control type="password" placeholder="Password" />
            </FloatingLabel>
            <div className='submit'>
                <button className='btn bg-primary text-light m-3'>Register</button>
            </div>
        </div>
        </>
    )
}
export default Registerform