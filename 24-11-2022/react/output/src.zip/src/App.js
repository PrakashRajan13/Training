
import 'bootstrap/dist/css/bootstrap.min.css';
import Main_route from './Main_Route';

function App() {
  return (
    <>
    <Main_route/>
    </>
  );
}

export default App;
