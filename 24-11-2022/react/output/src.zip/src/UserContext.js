import React from "react";

const Usercontext=React.createContext();

export default Usercontext;