
function Welcome(){
    return(<>
    <h1>welcome Prakash...!</h1>
    </>
    )
}
export default Welcome