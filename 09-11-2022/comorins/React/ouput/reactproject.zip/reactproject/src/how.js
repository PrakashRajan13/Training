function Hoow(props){
    return(
        <>
        <h2>How are you?</h2>
        <button onClick={()=>{props.changeName("user")}}>change</button>
        </>
    )
  }
  export default Hoow;